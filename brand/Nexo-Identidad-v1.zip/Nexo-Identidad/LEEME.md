# Nexo — Paquete de identidad 1.0

Empieza por `01-Manual/Nexo-Manual-de-Identidad.pdf` y `01-Manual/Nexo-Brand-Board.png`.

## Para usar el logo

- Uso habitual: `02-Logos/PNG-transparente/nexo-horizontal-principal.png`.
- Fondo verde u oscuro: `02-Logos/PNG-transparente/nexo-horizontal-blanco.png`.
- Diseño o imprenta: el SVG de la misma versión. Las letras están convertidas a trazados.
- Avatar: `05-Aplicaciones/avatar-1080x1080.png`.
- Los JPG tienen fondo fijo. Solo los PNG de `PNG-transparente` tienen canal alfa.

## Contenido

01 Manual: PDF, HTML editable y brand board SVG/PNG/JPG.
02 Logos: 40 SVG (transparentes y fondos), 20 PNG transparentes, 20 PNG con fondo y 20 JPG con fondo.
03 Colores: HEX/RGB/CMYK aproximado en CSV y JSON; variables CSS y paleta GPL.
04 Tipografías: Manrope y DM Sans, variables y 5 pesos estáticos TTF, WOFF2 y licencias.
05 Aplicaciones: plantillas SVG/PNG/JPG, firma HTML, iconos y favicon.
06 Referencia: cabecera actual y origen de la normalización.

Abre el HTML del manual manteniendo la estructura de carpetas para que encuentre imágenes y fuentes. Las plantillas SVG conservan textos en trazados; puedes sustituirlos en un editor vectorial usando las fuentes incluidas. Los campos de ejemplo no son contactos reales. Para imprimir, pide al proveedor sangrado y conversión al perfil de color de producción.
