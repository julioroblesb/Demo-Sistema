# Origen de esta identidad

Base: landing del repositorio julioroblesb/Demo-Sistema, commit 8e6d3c6b4b1ae56cf14da2aad7d3f8c92a192a7d. La revisión toma el código del 19 de octubre de 2026.

- Nombre, punto, paleta y tipografías: extraídos del sitio.
- Isotipo maestro: ocho direcciones del SVG `.tr-wordmark` de la demo. Se amplía sin alterar su proporción ni sus terminaciones redondeadas.
- Logotipo: Manrope 800 con espaciado compacto, convertido a trazados para reproducción estable. Se normaliza la composición; no es una captura exacta de los píxeles de la cabecera.
- La cabecera actual usa el carácter Unicode ✳, cuyo dibujo depende del sistema. Se incluye una captura de referencia y no se modificó la web al preparar este paquete.
- Reglas de seguridad, mínimos, versiones apiladas y aplicaciones: formalizadas en esta entrega. No eran un manual previo.
- Las tarjetas y portadas son plantillas; los contactos deben completarse. Los artes RGB necesitan preparación de imprenta cuando corresponda.
- Fuentes obtenidas de @fontsource-variable/manrope y @fontsource-variable/dm-sans, paquetes versión 5.3.0. Se incluyen archivos web, conversiones TTF e instancias 400/500/600/700/800 con sus licencias OFL.
- Nexo sigue siendo una denominación de trabajo; este paquete no acredita registro ni disponibilidad del nombre.
